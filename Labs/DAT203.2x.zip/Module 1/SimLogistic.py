def sim_log_data(x1, y1, n1, sd1, x2, y2, n2, sd2):
    import pandas as pd
    import numpy.random as nr
    
    wx1 = nr.normal(loc = x1, scale = sd1, size = n1)
    wy1 = nr.normal(loc = y1, scale = sd1, size = n1)
    z1 = [1]*n1
    wx2 = nr.normal(loc = x2, scale = sd2, size = n2)
    wy2 = nr.normal(loc = y2, scale = sd2, size = n2)
    z2 = [0]*n2
    
    df1 = pd.DataFrame({'x': wx1, 'y': wy1, 'z': z1})
    df2 = pd.DataFrame({'x': wx2, 'y': wy2, 'z': z2}) 
    return pd.concat([df1, df2], axis = 0, ignore_index = True)   


def plot_class(df):
    import matplotlib.pyplot as plt
    fig = plt.figure(figsize=(8, 8))
    fig.clf()
    ax = fig.gca()
    df[df.z == 1].plot(kind = 'scatter', x = 'x', y = 'y', ax = ax, 
                       alpha = 1.0, color = 'Red', marker = 'x', s = 40) 
    df[df.z == 0].plot(kind = 'scatter', x = 'x', y = 'y', ax = ax, 
                       alpha = 1.0, color = 'DarkBlue', marker = 'o', s = 40) 
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_title('Classes vs X and Y')
    return 'Done'


def logistic_mod(df, logProb = 1.0):
    from sklearn import linear_model

    ## Prepare data for model
    nrow = df.shape[0]
    X = df[['x', 'y']].as_matrix().reshape(nrow,2)
    Y = df.z.as_matrix().ravel() #reshape(nrow,1)
    ## Compute the logistic regression model
    lg = linear_model.LogisticRegression()
    logr = lg.fit(X, Y)
    ## Compute the y values
    temp = logr.predict_log_proba(X)  
    df['predicted']  = [1 if (logProb > p[1]/p[0]) else 0 for p in temp]
    return df

    
def eval_logistic(df):
    import matplotlib.pyplot as plt
    import pandas as pd

    truePos = df[((df['predicted'] == 1) & (df['z'] == df['predicted']))]  
    falsePos = df[((df['predicted'] == 1) & (df['z'] != df['predicted']))] 
    trueNeg = df[((df['predicted'] == 0) & (df['z'] == df['predicted']))]  
    falseNeg = df[((df['predicted'] == 0) & (df['z'] != df['predicted']))]

    fig = plt.figure(figsize=(8, 8))
    fig.clf()
    ax = fig.gca()
    truePos.plot(kind = 'scatter', x = 'x', y = 'y', ax = ax, 
                       alpha = 1.0, color = 'DarkBlue', marker = '+', s = 80) 
    falsePos.plot(kind = 'scatter', x = 'x', y = 'y', ax = ax, 
                       alpha = 1.0, color = 'Red', marker = 'o', s = 40)  
    trueNeg.plot(kind = 'scatter', x = 'x', y = 'y', ax = ax, 
                       alpha = 1.0, color = 'DarkBlue', marker = 'o', s = 40)  
    falseNeg.plot(kind = 'scatter', x = 'x', y = 'y', ax = ax, 
                       alpha = 1.0, color = 'Red', marker = '+', s = 80) 
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_title('Classes vs X and Y')
    
    TP = truePos.shape[0]
    FP = falsePos.shape[0]
    TN = trueNeg.shape[0]
    FN = falseNeg.shape[0]
       
    confusion = pd.DataFrame({'Positive': [FP, TP],
                              'Negative': [TN, FN]},
                               index = ['TrueNeg', 'TruePos'])
    accuracy = float(TP + TN)/float(TP + TN + FP + FN)      
    precision = float(TP)/float(TP + FP)     
    recall =  float(TP)/float(TP + FN)      
    
    print(confusion)
    print('accracy = ' + str(accuracy))
    print('precision = ' + str(precision))
    print('recall = ' + str(recall))
    
    return 'Done'   

def logistic_demo():
    import SimLogistic as sl
    x1vec = [1, 0.5, 0.1]
    y1vec = [1, 0.5, 0.1]
    x2vec = [-1, -0.5, -0.1]
    y2vec = [-1, -0.5, -0.1]
    for x1, y1, x2, y2 in zip(x1vec, y1vec, x2vec, y2vec):
        logt = sl.sim_log_data(x1, y1, 50, 1, x2, y2, 50, 1)
        logMod = sl.logistic_mod(logt)
        sl.eval_logistic(logMod)
    return 'Done'


def logistic_demo_prob():
    import SimLogistic as sl
    logt = sl.sim_log_data(0.5, 0.5, 50, 1, -0.5, -0.5, 50, 1)
    
    probs = [1, 2, 4]
    for p in probs:
        logMod = sl.logistic_mod(logt, p)
        sl.eval_logistic(logMod)
    return 'Done'
