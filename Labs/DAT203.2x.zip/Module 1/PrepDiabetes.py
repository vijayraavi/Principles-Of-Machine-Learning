def read_diabetes(pathName = 'SET-YOUR-PATH-HERE', fileName = 'diabetic_data.csv'):
    import pandas as pd
    import os
## Define the full file path and read the file
    filePath = os.path.join(pathName, fileName)
    return pd.read_csv(filePath)
 

def read_admissions(pathName = 'SET-YOUR-PATH-HERE', fileName = 'admissions_mapping.csv'):
    import pandas as pd
    import os
 ## Define the full file path and read the file
    filePath = os.path.join(pathName, fileName)
    return pd.read_csv(filePath) 


def prep_admissions(admissions):
    import pandas as pd
    admissions['admission_type_description'] = ['Unknown' if ((x in ['Not Available', 'Not Mapped', '?']) | (pd.isnull(x))) else x 
                                                 for x in admissions['admission_type_description']]
    return admissions


def join_diabetes(diabetes, admissions):
    return diabetes.merge(admissions, how = 'inner', on = 'admission_type_id', copy = False)


def missing_diabetes(diabetes):
    import pandas as pd
    import numpy as np
    cols = diabetes.columns.tolist()
    for col in cols:
        if diabetes[col].dtype in [np.int64, np.int32, np.float64] :
            diabetes[col] = [0 if pd.isnull(x) else x for x in diabetes[col]]
    for col in cols:
        if diabetes[col].dtype not in [np.int64, np.int32, np.float64] :
            diabetes[col] = ['unknown' if pd.isnull(x) else x for x in diabetes[col]]        
    return diabetes            

            

def prep_diabetes(pathName = 'SET-YOUR-PATH-HERE', fileName = '.'):
    import pandas as pd
    from sklearn import preprocessing
    import utilities as ut
    import numpy as np
    import os
 
 

def set_meds_class(x, cut):
    return [1 if (y > cut) else 0 for y in x]
    
    
def set_readmit_class(x):
    return ['NO' if (y == 'NO') else 'YES' for y in x]

  
 
def create_map():
    ## List of tuples with name and number of repititons.
    name_list = [('infections', 139),
                ('neoplasms', (239 - 139)),
                ('endocrine', (279 - 239)),
                ('blood', (289 - 279)),
                ('mental', (319 - 289)),
                ('nervous', (359 - 319)),
                ('sense', (389 - 359)),
                ('circulatory', (459-389)),
                ('respiratory', (519-459)),
                ('digestive', (579 - 519)),
                ('genitourinary', (629 - 579)),
                ('pregnancy', (679 - 629)),
                ('skin', (709 - 679)),
                ('musculoskeletal', (739 - 709)),
                ('congenital', (759 - 739)),
                ('perinatal', (779 - 759)),
                ('ill-defined', (799 - 779)),
                ('injury', (999 - 799))]
    ## Loop over the tuples to create a dictinary to map codes 
    ## to the names.
    out_dict = {}
    count = 1
    for name, num in name_list:
        for i in range(num):
          out_dict.update({str(count): name})  
          count += 1
    return out_dict
  

def map_codes(df, codes):
    import pandas as pd
    col_names = df.columns.tolist()
    for col in col_names:
        temp = [] 
        for num in df[col]:
            char1 = num.upper()[0]
            if ((num in ['unknown', '?']) | (pd.isnull(num))): temp.append('unknown')
            elif(char1 == 'V'): temp.append('supplemental')
            elif(char1 == 'E'): temp.append('injury')
            else: 
                lkup = num.split('.')[0]
                temp.append(codes[lkup])           
        df.loc[:, col] = temp               
    return df 
 
 
 
def set_missing(x):
    import pandas as pd
    import numpy as np
    indx = 0
    if x.dtype != np.int64:
        for num in x:
            if (num == 'unknown') | (num == '?') | pd.isnull(num): x[indx] = 'unknown'
            indx += 1
    return x
    
