read.diabetes <- function(pathName = 'SET-PATH-Here', fileName = 'diabetic_data.csv'){
  filePath <- file.path(pathName, fileName)
  read.csv(filePath, header = TRUE, stringsAsFactors = FALSE)
}


read.admissions <- function(pathName = 'SET-PATH-Here', fileName = 'admissions_mapping.csv'){
  filePath <- file.path(pathName, fileName)
  read.csv(filePath, header = TRUE, stringsAsFactors = FALSE)
}


clean.admissions <- function(admissions){
  library(dplyr)
  admissions %>% mutate(admission_type_description =
                                ifelse(admission_type_description %in% 
                                       c('Not Available', 'NULL', 'Not Mapped'),
                                       'unknown', admission_type_description))
}


join.admissions <- function(diabetes, admissions){
  require(dplyr)
  diabetes %>% left_join(admissions, by = 'admission_type_id')
  diabetes[, 'admission_type_id'] = NULL
  diabetes
}


missing.diabetes <- function(diabetes){
  data.frame(lapply(diabetes, clean.column), stringsAsFactors = FALSE) 
}

clean.column <- function(x){
  if(is.numeric(x)) ifelse((is.na(x) | is.null(x)), 0, x)
  else ifelse((is.na(x) | is.null(x) | x == 'unknown' | x == '?' | x == 'Not Available' | x == 'Not Mapped'), 'unknown', x)
}


read.diagnostics <- function(pathName = 'SET-PATH-Here', fileName = 'diagnostic_codes.csv'){
  filePath <- file.path(pathName, fileName)
  read.csv(filePath, header = TRUE, stringsAsFactors = FALSE)
}


set.codes.old <- function(x, codes){
  code <- codes$diagnosis
  i <- 1
  print(str(code))
  for(num in x){
    if(num == 'unknown' | is.na(num) | num == '?') {
      x[i] <- 'unknown'
    }else{  
      fchar <- toupper(substr(num, 1, 1))
      ifelse(fchar == 'E', x[i] <- 'injury',
             ifelse(fchar == 'V', x[i] <- 'suplemental',
                    x[i] <- code[as.integer(num)] 
             ))
    } 
    i <- i + 1 
  }
  x
}


set.codes <- function(x, codes){
  code <- codes$diagnosis
  i <- 1
  print(str(code))
  for(num in x){
    if(num == 'unknown' | is.na(num) | num == '?') {
      x[i] <- 'unknown'
    }else{  
      fchar <- toupper(substr(num, 1, 1))
      ifelse(fchar == 'E', x[i] <- 'injury',
             ifelse(fchar == 'V', x[i] <- 'suplemental',
                    x[i] <- code[as.integer(num)] 
             ))
    } 
    i <- i + 1 
  }
  x
}

class.readmit <- function(x){
  out <- rep("NO", length(x))
  out[which(x != "NO")] <- "YES"
  out
}

class.meds <- function(x, cut = 20){
  out <- rep("normal", length(x))
  out[which(x > cut)] <- "large"
  out
}
