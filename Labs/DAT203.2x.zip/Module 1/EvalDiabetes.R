frame1 <- maml.mapInputPort(1)

print('About to create the Score column')
## Assign scores to the cases.
frame1$Score = ifelse(frame1$readmitted == 'YES' & frame1$ScoredLabels == 'YES', 'TP',
                      ifelse(frame1$readmitted == 'NO' & frame1$ScoredLabels == "YES", 'FP',
                             ifelse(frame1$readmitted == 'NO' & frame1$ScoredLabels == 'NO', 'TN', 'FN')))
print('Created the Score column')

## Compair outcomes for various levels of 
## factor (categorical) features. 
library(ggplot2)
library(dplyr)
bar.plot <- function(x){
  if(is.factor(frame1[, x])){
    sums <- summary(frame1[, x], counts = n())
    msk <- names(sums[which(sums > 100)])
    tmp <- frame1[frame1[, x] %in% msk, c('Score', x)]
    if(strsplit(x, '[-]')[[1]][1] == x){
      g <- ggplot(tmp, aes_string(x)) +
        geom_bar() +
        facet_grid(. ~ Score) +
        ggtitle(paste('Readmissions by level of', x))
      print(g)    
    }    
  }    
}
cols <- names(frame1)
cols <- cols[1:(length(cols) - 1)]
lapply(cols, bar.plot)


## Histgrams of score probabilities
hist.plot <- function(x){
  if(is.factor(frame1[, x])){
    if(strsplit(x, '[-]')[[1]][1] == x){
      g <- ggplot(frame1, aes(ScoredProbabilities)) +
        geom_histogram() +
        facet_grid(x ~ .) +
        ggtitle(paste('Histograms of score probabilities for', x))
      print(g)    
    }    
  }    
}

lapply(cols, hist.plot)



## Box plot the numeric features
box.plot <- function(x){
  if(is.numeric(frame1[, x])){
    ggplot(frame1, aes_string('Score', x)) +
      geom_boxplot(alpha = 0.1) +
      ggtitle(paste('Readmissions by', x))
  }
}
dropCols <- ncol(frame1)
dropCols <- c((dropCols - 2):dropCols)
lapply(names(frame1[, -c(dropCols)]), box.plot)

## Scatter plots of scores by numeric features
scatter.plot <- function(x){
  if(is.numeric(frame1[, x])){
    ggplot(frame1, aes_string('ScoredProbabilities', x)) +
      geom_point(alpha = 0.2) +
      facet_grid(Score ~ .) +
      ggtitle(paste('Scored probability by', x))
  } else {
    frame1[, col] = as.numeric[, col]
    ggplot(frame1, aes_string('ScoredProbabilities', x)) +
      geom_point(alpha = 0.2) +
      facet_grid(Score ~ .) +
      ggtitle(paste('Scored probability by', x))
  }
}

lapply(cols, scatter.plot)